PLACEHOLDER-INTERVENTION TEST EVAL — DROP-IN PACKAGE
=====================================================

WHAT THIS IS
------------
A control eval for the intervention pipeline. The real intervention pipeline
(tau_bench/run.py, run_intervention=True branch) identifies a failure point
in a failed baseline trajectory, generates a corrective instruction with an
LLM, inserts it into the transcript, and continues the episode from there —
across N candidate interventions per task, using best-of-N scoring (a task
counts as solved if ANY of the N attempts succeeds).

This package reuses that exact same failure-point-identification and
graft-and-continue architecture, but replaces the LLM-generated corrective
text with a fixed, content-free placeholder sentence:

    "Please continue and do your best to complete the customer's
     request successfully."

The point: if real corrective content isn't actually adding value beyond the
architecture itself (getting another continuation attempt from the same
identified failure point), the placeholder should score about the same as
the real intervention. If real content is genuinely helping, the placeholder
should score meaningfully lower. Comparing "real intervention Bo-N" vs
"placeholder Bo-N" isolates the content's causal contribution from the
pipeline's structural effect.

FILES IN THIS ZIP
------------------
  tau_bench/placeholder.py           (NEW file — the placeholder-run logic)
  run_placeholder_intervention.py    (NEW file — CLI entry point)

Drop both into your repo at the same relative paths (tau_bench/placeholder.py
goes inside your tau_bench/ package; run_placeholder_intervention.py goes at
the repo root, alongside your existing run.py). Nothing else needs to be
added, removed, or overwritten — see "COMPATIBILITY CHECK" below for why.

COMPATIBILITY CHECK — WHAT I VERIFIED
---------------------------------------
I checked this against the origin/main state of this repo (HanavM/tau-bench)
to make sure dropping these two files into your existing copy will work
without needing any other file changes:

1. tau_bench/placeholder.py imports exactly these tau_bench internals:
     - tau_bench.envs.get_env
     - tau_bench.types.EnvRunResult, tau_bench.types.RunConfig
     - tau_bench.run.agent_factory
   All four are already present, unmodified, in the base repo you have.
   agent_factory in particular was diffed line-by-line against the current
   working copy here and is byte-identical to what's on GitHub — so you do
   NOT need to touch your tau_bench/run.py at all.

2. run_placeholder_intervention.py imports tau_bench.types.RunConfig,
   tau_bench.envs.user.UserStrategy, and tau_bench.placeholder.run_placeholder
   (the file above). Same story — nothing else required.

3. The placeholder pipeline calls agent.run_intervention(...) and
   agent.solve_with_intervention(...) — these already exist on
   ChatReActAgentIntervened (tau_bench/agents/chat_react_agent_intervened.py)
   in your base repo; this package does not modify or depend on any change
   to that file.

4. RunConfig fields used (baseline_path, best_of_N, task_ids, seed,
   max_concurrency, user_strategy, agent_strategy, model, model_provider,
   user_model, user_model_provider, env, temperature, task_split, log_dir)
   are all already defined in tau_bench/types.py in your base repo.

KNOWN DEPENDENCY GAP (pre-existing, not introduced by this package)
----------------------------------------------------------------------
tau_bench/agents/chat_react_agent_intervened.py imports the `docent` package
(pip name: docent-python). This is NOT listed in setup.py's install_requires
in this repo, so if it isn't already installed in your environment you'll
hit an ImportError the moment agent_factory tries to build a
"react-intervened" agent — which happens regardless of whether you use this
placeholder package or the real intervention pipeline, since both go through
the same agent class. If you hit this:

    pip install docent-python

Version installed on my end: docent-python==0.1.0a9
(also for reference: litellm==1.74.8, openai==1.97.1, pydantic==2.11.7 —
these ARE already in setup.py or pulled in transitively, no action needed)

USAGE
-----
Step 1 — you need a completed baseline run first (same as for the real
intervention pipeline): a folder under results/ containing transcript.json,
produced by e.g.:

    python3 run.py --model <model> --model-provider openai \
      --user-model <user_model> --user-model-provider openai \
      --env retail --agent-strategy tool-calling \
      --temperature 0.0 --seed 10 --num-trials 1 --log-dir results

Step 2 — run the placeholder eval against that baseline folder:

    python3 run_placeholder_intervention.py \
      --baseline_path results/<your_baseline_folder> \
      --model <model> --model-provider openai \
      --user-model <user_model> --user-model-provider openai \
      --env retail --agent-strategy react-intervened \
      --seed 10 --best_of_N 5 --temperature 0.0 --max-concurrency 10

Notes:
  - --agent-strategy must be react-intervened (the only strategy with
    run_intervention/solve_with_intervention).
  - Some models (e.g. gpt-5-mini and other reasoning-only models) reject
    temperature=0.0 and require the default (temperature=1). If you hit
    "Unsupported value: 'temperature' does not support 0.0", pass
    --temperature 1.0 instead.
  - --best_of_N is treated as a TARGET total attempts per failing task, not
    "attempts this call". Rerunning with a higher --best_of_N on the same
    baseline_path/model will top up existing tasks with more attempts rather
    than redoing them from scratch — safe to resume/extend an interrupted
    or smaller run.
  - Output is saved to results/<baseline_folder>/placeholder-by_<model>_<timestamp>/
    placeholder-transcripts.json, with one entry per attempt (not just the
    best one) so you can inspect every individual attempt's transcript.
  - The script prints a final "Placeholder Best-of-N performance" summary:
    a task counts as solved if ANY placeholder attempt solved it — directly
    comparable to however you're scoring the real intervention's Bo-N number.
